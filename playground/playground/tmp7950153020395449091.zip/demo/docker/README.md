### Start run.sh, it will process following task step by step
* build packages in repo
* build docker images
* docker compose up